# Release 0.1.0

Initial TensorFlow Runtime (TFRT) release.

TFRT’s initial open source release is an early preview of upcoming changes to
TensorFlow. Key interfaces like ops, kernels, and OpHandlers are still under
active development, so integrating other projects with TFRT is not recommended
at this time.

TFRT is currently developing workflows and continuous integration for accepting
contributions. The project is currently not accepting contributions, but this
policy will change as TFRT develops.
